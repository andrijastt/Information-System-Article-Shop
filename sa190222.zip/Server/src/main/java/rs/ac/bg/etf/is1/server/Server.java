package rs.ac.bg.etf.is1.server;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Configures JAX-RS for the application.
 * @author Juneau
 */
@ApplicationPath("")
public class Server extends Application {
    
}
